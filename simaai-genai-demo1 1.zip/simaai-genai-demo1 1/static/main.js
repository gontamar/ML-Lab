let mediaRecorder;
let audioChunks = [];

var intro = "Hello! Welcome to SiMa.ai Llama demo";


const socket = io();
const messageQueue = [];  // Queue to hold incoming messages
var talkQueue = [];

var results = document.getElementById("results");
var question = document.getElementById("question");
var reset = document.getElementById("reset");

let isProcessing = false;
let isTalking = false;
let isTyping = false;  // Flag to track if typing is in progress

const defaultQuestions = [
    "What do you see in this image?",
    "Can you describe the image?",
    "Is there any object in the image?",
    "Can I park my car?"
];


window.onload = function (){
    console.log('Loading app');
}

// Function to find the best matching default question
function findBestMatch(userQuery) {
    // Simple keyword matching logic
    const keywords = {
        "What do you see in this image?": ["see", "what", "view", "look", "observe"],
        "Can you describe the image?": ["describe", "tell", "explain", "detail", "about"],
        "Is there any object in the image?": ["object", "thing", "item", "detect", "find", "any"],
        "Can I park my car?": ["park", "parking", "car", "vehicle", "space", "safe"]
    };
    
    let bestMatch = defaultQuestions[0]; // Default fallback
    let maxScore = 0;
    
    for (const [question, keywordList] of Object.entries(keywords)) {
        let score = 0;
        for (const keyword of keywordList) {
            if (userQuery.includes(keyword)) {
                score++;
            }
        }
        if (score > maxScore) {
            maxScore = score;
            bestMatch = question;
        }
    }
    
    return bestMatch;
}

// Function to capture current frame from uploaded video
async function captureFrameFromVideo() {
    const videoPreview = document.getElementById("videoPreview");
    const previewImage = document.getElementById("imagePreview");
    const canvas = document.getElementById("captureCanvas");
    const context = canvas.getContext("2d");

    if (!videoPreview.currentSrc || videoPreview.paused) {
        console.log("No video playing, cannot capture frame");
        return;
    }

    // Capture current frame
    canvas.width = videoPreview.videoWidth;
    canvas.height = videoPreview.videoHeight;
    context.drawImage(videoPreview, 0, 0, canvas.width, canvas.height);

    // Convert to blob and update file input
    return new Promise((resolve) => {
        canvas.toBlob(function(blob) {
            const url = URL.createObjectURL(blob);
            previewImage.src = url;
            previewImage.style.display = "block";

            // Create file and update file input
            const file = new File([blob], "captured_frame.jpg", { type: "image/jpeg" });
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(file);
            document.getElementById('fileInput').files = dataTransfer.files;
            
            console.log("Frame captured from video successfully");
            resolve();
        }, "image/jpeg");
    });
}

function stopRecording() {
    mediaRecorder.stop();
    console.log("Recording stopped...");
}

function enableButtons() {
    document.getElementById("startRecord").disabled = false;
    document.getElementById("stopRecord").disabled = true;
    document.getElementById("capture").disabled = false;
    document.getElementById("sceneAnalyze").disabled = false;
    document.getElementById("reset").disabled = false;
}


// function handleFile(event) {
//     const file = event.target.files[0];
//     if (!file) return;

//     const previewImage = document.getElementById("imagePreview");
//     const videoPreview = document.getElementById("videoPreview");
//     const videoSource = document.getElementById("videoSource");

//     const fileURL = URL.createObjectURL(file);
//     const fileType = file.type;

//     if (fileType.startsWith('video/')) {
//         // Hide image, show video
//         previewImage.style.display = 'none';
//         videoPreview.style.display = 'block';
//         videoSource.src = fileURL;
//         videoPreview.load();
//     } else if (fileType.startsWith('image/')) {
//         // Hide video, show image
//         videoPreview.style.display = 'none';
//         previewImage.style.display = 'block';
//         previewImage.src = fileURL;
//     } else {
//         alert("Unsupported file type. Please upload an image or video.");
//     }
// }

function handleFile(event) {
    const file = event.target.files[0];
    if (!file) return;

    const previewImage = document.getElementById("imagePreview");
    const videoPreview = document.getElementById("videoPreview");
    const videoSource = document.getElementById("videoSource");

    const fileURL = URL.createObjectURL(file);
    const fileType = file.type;

    if (fileType.startsWith('video/')) {
        // Hide image, show video
        previewImage.style.display = 'none';
        videoPreview.style.display = 'block';
        videoSource.src = fileURL;
        videoPreview.load();
        videoPreview.play();  // Start playing automatically

        // Enable Begin Record button only if video is uploaded
        document.getElementById("startRecord").disabled = false;
    } else if (fileType.startsWith('image/')) {
        // Hide video, show image
        videoPreview.style.display = 'none';
        previewImage.style.display = 'block';
        previewImage.src = fileURL;

        // Disable Begin Record if image is uploaded (only allow recording after video upload)
        document.getElementById("startRecord").disabled = true;
    } else {
        alert("Unsupported file type. Please upload a video file to use the recording feature.");
        document.getElementById("startRecord").disabled = true;
    }
}

// async function captureImage() {
//     try {
//         const response = await fetch('/capture_and_send', { method: 'POST' });
//         const result = await response.json();

//         // Update status and display the captured image
//         // document.getElementById("status").textContent = "Image sent. Server response: " + result.response;
        
//         // Display the captured image if available
//         if (result.image_src) {
//             const capturedImage = document.getElementById("imagePreview");
//             capturedImage.src = result.image_src;
//             capturedImage.style.display = "block";

//             const fileInput = document.getElementById('fileInput');
//             console.log(fileInput.files.length);
//             fileInput.value = "";
//         }
//     } catch (error) {
//         console.log("Error sending image" ,error);
//     }
// }
async function captureImage() {
  const videoPreview = document.getElementById("videoPreview");
  const previewImage = document.getElementById("imagePreview");
  const canvas = document.getElementById("captureCanvas");
  const context = canvas.getContext("2d");

  if (videoPreview.currentSrc === "" || videoPreview.paused) {
    alert("No video is playing to capture.");
    return;
  }

  // Capture current frame
  canvas.width = videoPreview.videoWidth;
  canvas.height = videoPreview.videoHeight;
  context.drawImage(videoPreview, 0, 0, canvas.width, canvas.height);

  // Show captured frame in imagePreview
  canvas.toBlob(function(blob) {
    const url = URL.createObjectURL(blob);
    previewImage.src = url;
    previewImage.style.display = "block";

    // Simulate a file input so 'Analyze Scene' can use it later
    const file = new File([blob], "captured.jpg", { type: "image/jpeg" });
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    document.getElementById('fileInput').files = dataTransfer.files;
  }, "image/jpeg");
}

async function startRecording() {
    question.textContent = '';
    results.textContent = '';

    const fileInput = document.getElementById('fileInput');
    if (fileInput.files.length == 0)
        fileInput.value = '';
    
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorder = new MediaRecorder(stream);

    mediaRecorder.ondataavailable = function(event) {
        audioChunks.push(event.data);
    };

    mediaRecorder.onstop = async function() {
        const formData = new FormData();

        // Check if a file is selected
        if (fileInput.files.length != 0) {
            formData.append('image_data', fileInput.files[0], 'image.jpg');
        }
        
        const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
        audioChunks = [];

        formData.append('audio_data', audioBlob, 'audio.webm');

        try {
            const response = await fetch('/upload', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const jsonResponse = await response.json();
            const userQuery = jsonResponse['question'].toLowerCase().trim();

            // Find the best matching default question
            let matchedQuestion = findBestMatch(userQuery);
            
            question.style.visibility = 'visible';
            question.textContent = "Q: " + matchedQuestion;

            console.log("User query:", userQuery);
            console.log("Matched with default question:", matchedQuestion);

            // Automatically capture current frame from video and send query
            await captureFrameFromVideo();
            await new Promise(resolve => setTimeout(resolve, 500)); // Delay to ensure image is ready

            sendQueryWithImage(matchedQuestion);  // Send image + matched question to model

        } catch (error) {
            console.error('Fetch error:', error);
        }
    };

    mediaRecorder.start();
    console.log("Recording started...");
}

async function sendQuery() {
    question.textContent = '';
    results.textContent = '';

    const formData = new FormData();
    const fileInput = document.getElementById('fileInput');

    // Check if a file is selected
    if (fileInput.files.length != 0) {
        formData.append('image_data', fileInput.files[0], 'image.jpg');
    }
    
    try {
        const response = await fetch('/upload_image', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const jsonResponse = await response.json();
        question.style.visibility = 'visible';
        question.textContent = "Q: " + jsonResponse['question'];
    } catch (error) {
        console.error('Fetch error:', error);
    }
}

// New function to send query with matched question and captured image
async function sendQueryWithImage(matchedQuestion) {
    const formData = new FormData();
    const fileInput = document.getElementById('fileInput');

    // Add the captured image
    if (fileInput.files.length != 0) {
        formData.append('image_data', fileInput.files[0], 'captured_frame.jpg');
    }
    
    try {
        const response = await fetch('/upload_image_with_question', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Question': matchedQuestion  // Send the matched question in header
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        console.log("Image and question sent to model successfully");
    } catch (error) {
        console.error('Error sending query with image:', error);
    }
}

socket.on('update', (data) => {
    if (data["results"]) {
        if (data["results"] == "END") {
            enableButtons();
            isTyping = false;  // Reset typing flag
            return;
        }
        messageQueue.push(data["results"]);  // Queue up incoming data
        processQueue();  // Process the queue
    } else {
        console.log("Unhandled progress item");
    }
});

socket.on('talk', (data) => {
    if (data["results"]) {
        talkQueue.push(data["results"]);
        playTextAsSpeech();  // Call only once — queue will process further
    }
});


// async function talk(text) {
//     var utterance = null;

//     console.log('Talking', text);
//     utterance = new SpeechSynthesisUtterance(w);
//     utterance.rate = 0.9;

//     window.speechSynthesis.speak(utterance);
//     utterance.onend = () => {

//     };
// }

async function processQueue() {
    if (isProcessing || messageQueue.length == 0) {
        console.log('Returning ', isProcessing);
        return;
    }

    isProcessing = true;
    
    if (isTyping || messageQueue.length === 0)
        return;

    var resp_text = messageQueue.shift();
    if (resp_text.includes('<0x0A>'))
        resp_text = resp_text.replace(/<0x0A>/g, '\n');

    if (resp_text.includes('</s>'))
        resp_text = resp_text.replace(/<\/s>/g, '');
    
    resp_text +=  " ";
    isTyping = true;
    
    if (resp_text === "END") {
        console.log('Done with processing, playing', results.textContent);
        enableButtons();
        isTyping = false;
        return;
    }
    
    results.style.visibility = 'visible';
    if (results.textContent.length === 0) {
        results.textContent = "MMAI says: ";
    }

    let index = 0;
    function typeCharacter() {
        if (index < resp_text.length) {
            results.textContent += resp_text.charAt(index);
            index++;
            setTimeout(typeCharacter, 5);
        } else {
            isTyping = false;
            processQueue();
            results.textContent += " ";
        }
    }

    typeCharacter();
    isProcessing = false;
}

// function playTextAsSpeech() {
//     // const textChunks = text.split(/(?<=[.!?])\s+/); // Split text by sentence endings
//     if (isTalking || talkQueue.length == 0) {
//         return;
//     }

//     isTalking = true;

//     var textChunk = talkQueue.shift();
//     console.log('Text', textChunk);
    
//     const utterance = new SpeechSynthesisUtterance(textChunk.trim());
//     utterance.rate = 0.9;
//     window.speechSynthesis.speak(utterance);

//     isTalking = false;
// }
function playTextAsSpeech() {
    // Cancel any ongoing speech to prevent overlapping
    // window.speechSynthesis.cancel(); 

    if (isTalking || talkQueue.length === 0) {
        return;
    }

    isTalking = true;

    const textChunk = talkQueue.shift();
    console.log('Speaking:', textChunk);

    const utterance = new SpeechSynthesisUtterance(textChunk.trim());
    utterance.rate = 0.9;

    utterance.onend = () => {
        isTalking = false;
        playTextAsSpeech(); // Continue with next in queue
    };

    window.speechSynthesis.speak(utterance);
}

// function resetImage() {
//     const previewImage = document.getElementById("imagePreview");
//     previewImage.src = '/static/default.jpg';

//     const fileIn = document.getElementById('fileInput');
//     fileIn.value = '';

//     question.textContent = '';
//     results.textContent = '';
// }
function resetImage() {
    const previewImage = document.getElementById("imagePreview");
    const fileIn = document.getElementById('fileInput');
    const videoPreview = document.getElementById("videoPreview");
    const videoSource = document.getElementById("videoSource");

    // Reset image preview to default
    previewImage.src = '/static/default.jpg';
    previewImage.style.display = 'block';

    // Clear video
    videoSource.src = '';
    videoPreview.load();
    videoPreview.style.display = 'none';

    // Clear file input
    fileIn.value = '';

    // Clear question and results
    question.textContent = '';
    results.textContent = '';
    question.style.visibility = 'hidden';
    results.style.visibility = 'hidden';

    // Reset button states - disable Begin Record until video is uploaded
    document.getElementById("startRecord").disabled = true;
    document.getElementById("stopRecord").disabled = true;
    document.getElementById("capture").disabled = false;
    document.getElementById("sceneAnalyze").disabled = false;
    document.getElementById("reset").disabled = false;
}


document.getElementById("startRecord").addEventListener("click", function() {
    startRecording();
    document.getElementById("startRecord").disabled = true;
    document.getElementById("stopRecord").disabled = false;
    document.getElementById("capture").disabled = true;
    document.getElementById("sceneAnalyze").disabled = true;
    document.getElementById("reset").disabled = true;
});

document.getElementById("reset").addEventListener("click", function() {
    resetImage();
});

document.getElementById("sceneAnalyze").addEventListener("click", function() {
    sendQuery();
    document.getElementById("startRecord").disabled = true;
    document.getElementById("stopRecord").disabled = true;
    document.getElementById("capture").disabled = true;
    document.getElementById("sceneAnalyze").disabled = true;
    document.getElementById("reset").disabled = true;
});

document.getElementById("stopRecord").addEventListener("click", function() {
    stopRecording();
    document.getElementById("startRecord").disabled = true;
    document.getElementById("stopRecord").disabled = true;
    document.getElementById("capture").disabled = true;
});
document.getElementById("capture").addEventListener("click", function() {
    captureImage();
});
